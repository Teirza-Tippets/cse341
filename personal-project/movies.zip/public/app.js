import { loadMovies } from './controllers/controller.js';

document.addEventListener('DOMContentLoaded', () => {
    loadMovies();
});
